<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Keranjang Belanja</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body>

    <header>
        <h1>Keranjang Belanja</h1>
        <nav>
            <a href="/">Kembali ke Katalog</a>
        </nav>
    </header>

    <main class="container">
        <h2>Produk di Keranjang</h2>

        <?php if(session('success')): ?>
            <p><?php echo e(session('success')); ?></p>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <p><?php echo e(session('error')); ?></p>
        <?php endif; ?>

        <?php
            $total = 0;
        ?>

        <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php if($item->product): ?>
                <?php
                    $subtotal = $item->product->harga * $item->jumlah;
                    $total += $subtotal;
                ?>

                <div class="product-card">
                    <h3><?php echo e($item->product->nama_barang); ?></h3>
                    <p>Harga: Rp<?php echo e(number_format($item->product->harga, 0, ',', '.')); ?></p>
                    <p>Jumlah: <?php echo e($item->jumlah); ?></p>
                    <form action="<?php echo e(route('cart.update', $item->id_cart_item)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <input
                            type="number"
                            name="jumlah"
                            value="<?php echo e($item->jumlah); ?>"
                            min="1"
                            max="<?php echo e($item->product->stok); ?>"
                            required
                        >

                        <button type="submit">Ubah Jumlah</button>
                    </form>

                    <form action="<?php echo e(route('cart.remove', $item->id_cart_item)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>

                        <button type="submit">Hapus</button>
                    </form>
                    <p>Subtotal: Rp<?php echo e(number_format($subtotal, 0, ',', '.')); ?></p>
                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p>Keranjang masih kosong.</p>
        <?php endif; ?>

        <h3>Total: Rp<?php echo e(number_format($total, 0, ',', '.')); ?></h3>
        <?php if($items->isNotEmpty()): ?>
            <a href="<?php echo e(route('checkout.index')); ?>">
                <button type="button">Lanjut ke Checkout</button>
            </a>
        <?php endif; ?>
    </main>

</body>
</html><?php /**PATH C:\Users\WORKPLUS\toko-online\resources\views/cart.blade.php ENDPATH**/ ?>