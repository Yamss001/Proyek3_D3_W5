<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Katalog Toko Online</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body>

    <header>
        <h1>Toko Online</h1>

        <nav>
            <?php if(auth()->guard()->check()): ?>
                <span>Halo, <?php echo e(Auth::user()->nama_lengkap); ?></span>

                <a href="<?php echo e(route('logout')); ?>"
                   onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                    Logout
                </a>

                <form id="logout-form" action="<?php echo e(route('logout')); ?>"
                      method="POST" style="display:none;">
                    <?php echo csrf_field(); ?>
                </form>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>">Login</a>
            <?php endif; ?>
        </nav>
    </header>

    <main class="container">
        <h2>Katalog Produk</h2>
        <p>Pilih perlengkapan sekolah yang kamu butuhkan.</p>

        <div class="product-grid">
            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="product-card">

                    <?php if($product->gambar): ?>
                        <img
                            src="<?php echo e(asset('images/' . $product->gambar)); ?>"
                            alt="<?php echo e($product->nama_barang); ?>"
                        >
                    <?php endif; ?>

                    <h3><?php echo e($product->nama_barang); ?></h3>

                    <p class="price">
                        Rp<?php echo e(number_format($product->harga, 0, ',', '.')); ?>

                    </p>
                    
                    <p class="stock">
                        Stok: <?php echo e($product->stok); ?>

                    </p>

                    <?php if($product->stok > 0): ?>
                        <p>Tersedia</p>
                    <?php else: ?>
                        <p>Stok habis</p>
                    <?php endif; ?>
                    <?php if($product->stok > 0): ?>
                    <?php if(auth()->guard()->check()): ?>
                            <form action="<?php echo e(route('cart.add', $product->id_barang)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button type="submit">Tambah ke Keranjang</button>
                            </form>
                        <?php else: ?>
                            <a href="<?php echo e(route('login')); ?>">Login untuk membeli</a>
                        <?php endif; ?>
                    <?php else: ?>
                        <button disabled>Stok Habis</button>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p>Belum ada produk.</p>
            <?php endif; ?>
        </div>
    </main>

</body>
</html><?php /**PATH C:\Users\WORKPLUS\toko-online\resources\views/home.blade.php ENDPATH**/ ?>