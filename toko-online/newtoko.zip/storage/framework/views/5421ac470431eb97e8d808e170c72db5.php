<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login</title>
</head>
<body>
    <h1>Login</h1>
    <p>Masuk untuk membuka dashboard</p>

    
    <?php if($errors->any()): ?>
        <div role="alert">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p>[ <?php echo e($error); ?> ]</p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('login')); ?>">
        <?php echo csrf_field(); ?>

        <p>
            <label for="username">Username</label><br>
            <input
                type="text"
                id="username"
                name="username"
                value="<?php echo e(old('username')); ?>"
                autocomplete="username"
                <?php echo e(old('username') ? '' : 'autofocus'); ?>

            >
        </p>

        <p>
            <label for="password">Password</label><br>
            <input
                type="password"
                id="password"
                name="password"
                autocomplete="current-password"
                <?php echo e(old('username') ? 'autofocus' : ''); ?>

            >
        </p>

        <button type="submit">Masuk</button>
    </form>
</body>
</html><?php /**PATH C:\Users\WORKPLUS\Documents\Kuliah Semester 3\Proyek3_W5\toko-online\resources\views/login.blade.php ENDPATH**/ ?>