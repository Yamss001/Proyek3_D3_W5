
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Riwayat Pemesanan</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body>
    <div class="container">
        <h1>Riwayat Pemesanan</h1>

        <a href="<?php echo e(url('/home')); ?>">Kembali ke Katalog</a>

        <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="order-card">
                <h3>Pesanan: <?php echo e($order->id_order); ?></h3>

                <p>
                    Tanggal:
                    <?php echo e($order->tanggal_order); ?>

                </p>

                <p>
                    Alamat pengiriman:
                    <?php echo e($order->alamat_pengiriman); ?>

                </p>

                <h4>Barang yang dipesan</h4>

                <?php $__currentLoopData = $order->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="order-item">
                        <img
                            src="<?php echo e(asset('images/' . $detail->gambar)); ?>"
                            alt="<?php echo e($detail->nama_barang); ?>"
                            width="70"
                        >

                        <span><?php echo e($detail->nama_barang); ?></span>
                        <span><?php echo e($detail->jumlah); ?> buah</span>

                        <span>
                            Rp<?php echo e(number_format(
                                $detail->harga * $detail->jumlah,
                                0, ',', '.'
                            )); ?>

                        </span>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <h3>
                    Total:
                    Rp<?php echo e(number_format($order->total_harga, 0, ',', '.')); ?>

                </h3>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p>Belum ada riwayat pemesanan.</p>
        <?php endif; ?>
    </div>
</body>
</html>
<?php /**PATH C:\Users\WORKPLUS\toko-online\resources\views/orders/index.blade.php ENDPATH**/ ?>