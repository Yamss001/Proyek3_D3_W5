<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body>

    <header>
        <h1>Checkout</h1>
        <nav>
            <a href="/cart">Kembali ke Keranjang</a>
        </nav>
    </header>

    <main class="container">
        <h2>Ringkasan Pesanan</h2>

        <?php if($errors->any()): ?>
            <p>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($error); ?><br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </p>
        <?php endif; ?>

        <?php
            $total = 0;
        ?>

        <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php if($item->product): ?>
                <?php
                    $subtotal = $item->product->harga * $item->jumlah;
                    $total += $subtotal;
                ?>

                <div class="product-card">
                    <h3><?php echo e($item->product->nama_barang); ?></h3>
                    <p>Harga satuan:
                        Rp<?php echo e(number_format($item->product->harga, 0, ',', '.')); ?>

                    </p>
                    <p>Jumlah: <?php echo e($item->jumlah); ?></p>
                    <p>Subtotal:
                        Rp<?php echo e(number_format($subtotal, 0, ',', '.')); ?>

                    </p>
                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p>Keranjang masih kosong.</p>
        <?php endif; ?>

        <h3>Total:
            Rp<?php echo e(number_format($total, 0, ',', '.')); ?>

        </h3>

        <?php if($items->isNotEmpty()): ?>
            <form action="<?php echo e(route('checkout.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <label for="alamat_pengiriman">
                    Alamat Pengiriman
                </label>

                <textarea
                    id="alamat_pengiriman"
                    name="alamat_pengiriman"
                    rows="4"
                    required
                ><?php echo e(old('alamat_pengiriman')); ?></textarea>

                <br><br>

                <button type="submit">Buat Pesanan</button>
            </form>
        <?php endif; ?>
    </main>

</body>
</html><?php /**PATH C:\Users\WORKPLUS\toko-online\resources\views/checkout.blade.php ENDPATH**/ ?>